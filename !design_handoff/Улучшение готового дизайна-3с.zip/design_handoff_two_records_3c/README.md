# Handoff: Two-Records compact card — variant **3c** (desktop, mirrored)

## Overview
A **compact single-line-per-gender** record card that shows the national age-group record
for the currently selected event, for **both genders side by side** (♂ left, ♀ right).
It is the desktop counterpart to the mobile "two records" strip — deliberately **short in
height**: a centered title on top, then one dense row per gender.

Layout intent (3c):
- **Centered header** on top: `🏅 National Record · {age}y`.
- **Two columns** split by a thin vertical divider.
- **Left column = male (♂)**, natural reading order: `time · name/club/date · ♂ pill`
  (gender pill sits on the **right** edge of its column, pushed by `margin-left:auto`).
- **Right column = female (♀)** is the **mirror image**: same widgets in reverse
  (`flex-direction: row-reverse`), so the ♀ pill sits on the **left** edge, time on the
  outer right, and name/club/date are **right-aligned**.
- Under each holder name: **club** then **record date** (small, muted), stacked.

The point of the mirror is visual symmetry — the two gender pills hug the **outer** edges
of the card, the two times sit **innermost** next to the center divider.

## About the design files
`Age Records Mobile.dc.html` is an **HTML design reference** running on a tiny in-house
template runtime (`support.js`) so it can open standalone. **Ignore that runtime.** Read
the markup of the block whose wrapper is `id="3c"` and the `class Component` logic for the
data mapping. Recreate the design **inside the existing React/TypeScript + Tailwind
codebase** — do not copy the prototype verbatim.

> The file contains several sibling variants (3a, 3b, 2e, 2f). **Only `#3c` is in scope.**

## Target file
Same component as the age-records work:
**`client/src/projects/results-table/components/normative-age-records.tsx`**
(or wherever the two-records/single-age view is rendered). Keep the public API and data
logic **unchanged** — only the render/markup + styling of this compact two-record view
change. Reuse existing props (`gender, poolType, styleName, styleLen, age`) and the
`window.normative_age_record` data source.

## Fidelity
**High-fidelity.** The values below are final. Recreate pixel-close with Tailwind classes
(arbitrary values where no token exists). Since the codebase is **Tailwind**, the handoff
is expressed as Tailwind utilities, not raw CSS.

---

## Data (unchanged)
`window.normative_age_record.normatives[gender][poolKey][styleName][distanceKey][ageKey]`
→ leaf `{ time, name, club, country, record_date }`.
`name` / `club` are Hebrew → render **RTL** (`dir="rtl"`, `unicode-bidi: isolate`).
`record_date` may be `""` → fall back to `"—"`.

For 3c you need, for the selected `age`, the **male** and **female** leaf:
```
const m = recs('male')[age]   // { time, name, club, record_date }
const f = recs('female')[age]
```

---

## Structure & Tailwind spec (variant 3c)

### Outer card
```
<div class="w-[620px] rounded-[14px] bg-white shadow-[0_1px_3px_rgba(20,28,45,0.06)]
            px-[18px] pt-2 pb-[9px]">
```
(Prototype wraps this in a grey desk tile `#f5f5f7` + big shadow — that's demo chrome, **not**
part of the component. Ship just the white card, or on the app's `surface` token.)

### Header (centered, on top)
```
<div class="flex items-center justify-center gap-1.5 mb-[7px]">
  <span class="text-[12px]">🏅</span>
  <span class="text-[9px] font-extrabold tracking-[0.09em] uppercase text-[#9098a4]">
    National Record · {age}y
  </span>
</div>
```

### Two-column grid
```
<div class="grid grid-cols-[1fr_1px_1fr] gap-[18px] items-center">
  … male row …
  <div class="self-stretch bg-[#e9edf3]"></div>   {/* center divider */}
  … female row (mirrored) …
</div>
```

### Male row (♂ — normal direction, pill on right)
```
<div class="flex items-center gap-2.5 min-w-0">
  <div class="shrink-0 text-[22px] font-extrabold tabular-nums tracking-[-0.6px] text-[#123a70]">
    {m.time}
  </div>
  <div class="min-w-0">
    <div dir="rtl" class="font-heebo text-[12px] font-bold text-[#1a1a1a] text-left truncate">{m.name}</div>
    <div dir="rtl" class="font-heebo text-[10px] text-[#8a93a3] text-left truncate">{m.club}</div>
    <div class="text-[9px] text-[#aab0bd] tabular-nums text-left mt-px">{m.record_date || '—'}</div>
  </div>
  <span class="shrink-0 ml-auto text-[10px] font-extrabold text-[#1e6fd6] bg-[#eaf2fd]
               px-[9px] py-[3px] rounded-full">♂ Man</span>
</div>
```

### Female row (♀ — mirrored: `flex-row-reverse`, pill on left, text right-aligned)
```
<div class="flex flex-row-reverse items-center gap-2.5 min-w-0">
  <div class="shrink-0 text-[22px] font-extrabold tabular-nums tracking-[-0.6px] text-[#7a1f4b]">
    {f.time}
  </div>
  <div class="min-w-0">
    <div dir="rtl" class="font-heebo text-[12px] font-bold text-[#1a1a1a] text-right truncate">{f.name}</div>
    <div dir="rtl" class="font-heebo text-[10px] text-[#8a93a3] text-right truncate">{f.club}</div>
    <div class="text-[9px] text-[#aab0bd] tabular-nums text-right mt-px">{f.record_date || '—'}</div>
  </div>
  <span class="shrink-0 mr-auto text-[10px] font-extrabold text-[#d6417f] bg-[#fdeff5]
               px-[9px] py-[3px] rounded-full">Woman ♀</span>
</div>
```

**Why it mirrors correctly:** in the ♀ row `flex-row-reverse` flips child order, so `time`
lands on the far right (outer edge), the pill's `mr-auto` shoves it to the far left (outer
edge), and the holder text is `text-right`. The ♂ row is the plain-direction twin.

---

## Design tokens (light)
| token | ♂ male | ♀ female |
|---|---|---|
| time / deep text | `#123a70` | `#7a1f4b` |
| pill text (accent) | `#1e6fd6` | `#d6417f` |
| pill bg (soft) | `#eaf2fd` | `#fdeff5` |
| pill label | `♂ Man` | `Woman ♀` |

| ui | value |
|---|---|
| card bg / surface | `#ffffff` |
| holder name | `#1a1a1a` |
| club (muted) | `#8a93a3` |
| date (faint) | `#aab0bd` |
| header label | `#9098a4` |
| center divider | `#e9edf3` |
| card radius | `14px` |
| card shadow | `0 1px 3px rgba(20,28,45,0.06)` |

**Dark theme** (if you support it, mirror the age-records handoff palette): swap surface to
`#161b24`, divider `#28303c`, and use the dark gender accents
(♂ `#5aa2f5`/`#dbe8fb`, ♀ `#f072a6`/`#fbdcec`, soft pills at `rgba(...,0.16)`).

## Type
- UI: **Inter**. Hebrew name/club: **Heebo** (or the app's existing Hebrew font), RTL isolated.
- Time uses `tabular-nums`.

## Behavior
- **No interactions** — static card. No hover, no click.
- Render only when a male **or** female record exists for the selected age; fall back
  `"—"` for a missing `time` / empty `record_date`.
- The prototype's grey desk background, the `3c` badge, and the section caption are
  **demo-only** — do not port.

## Responsive note
`w-[620px]` is the desktop width. For narrower breakpoints let it go fluid
(`w-full max-w-[620px]`); the two rows already truncate long Hebrew names via `truncate`
+ `min-w-0`.

## Files in this bundle
- `Age Records Mobile.dc.html` — design prototype; read the `id="3c"` block + `class Component`.
- `data/normative-age-records.js` — real dataset (already in app at
  `client/public/data/normative-age-records.js`).
- `support.js` — prototype runtime only; **ignore**.
